export const environment = {
  production: true,
  watchlistAPI: 'http://ec2-18-220-245-72.us-east-2.compute.amazonaws.com:3000/watchlist',
  symbolAPI: 'http://ec2-18-220-245-72.us-east-2.compute.amazonaws.com:3000/symbol',
  userAPI: 'http://ec2-18-220-245-72.us-east-2.compute.amazonaws.com:3000/user',
  yahooAPI: 'http://ec2-18-220-245-72.us-east-2.compute.amazonaws.com:3000/yahoo-finance',
  orderAPI: 'http://ec2-18-220-245-72.us-east-2.compute.amazonaws.com:3000/order',
  stockWS: 'http://ec2-18-220-245-72.us-east-2.compute.amazonaws.com:3000/ws'
};

