export interface UserAuthRequestDto {
  email: string;
  password: string;
  authenticationType: string;
}
