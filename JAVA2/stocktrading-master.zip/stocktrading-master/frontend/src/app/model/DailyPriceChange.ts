export class DailyPriceChange{
  symbol: string;
  price: number;
  change: number;
  changeInPercent: number;
  prevClose: number;
  constructor() {  }
}
