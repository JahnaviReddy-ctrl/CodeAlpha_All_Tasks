export interface SummaryStock{
  symbol: string;
  currentPrice: number;
  change: number;
  changePercent: number;
}
