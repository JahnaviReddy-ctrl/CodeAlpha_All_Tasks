export class Symbol {
  symbolId: number;
  symbol: string;
  name: string;
  constructor() {
  }
}
