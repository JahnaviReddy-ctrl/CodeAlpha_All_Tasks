export interface News {
  symbol: string;
  description: string;
  guid: string;
  link: string;
  pubDate: string;
  title: string;
}
