export interface Payload {
  email: string;
  userId: string;
}
