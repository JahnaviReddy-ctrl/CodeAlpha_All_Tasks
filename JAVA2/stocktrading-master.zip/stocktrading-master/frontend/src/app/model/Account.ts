export class Account{
  userId: string;

  initialValue: number;

  netAccountValue: number;

  overallPL: number;

  PLChange: number;

  marketValue: number;

  buyingPower: number;

  constructor() {  }
}

