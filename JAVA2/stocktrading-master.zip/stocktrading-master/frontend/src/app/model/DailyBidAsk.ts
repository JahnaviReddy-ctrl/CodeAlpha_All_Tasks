export class DailyBidAsk{
  bid: number;
  ask: number;
  spread: number;
  constructor() {  }
}
