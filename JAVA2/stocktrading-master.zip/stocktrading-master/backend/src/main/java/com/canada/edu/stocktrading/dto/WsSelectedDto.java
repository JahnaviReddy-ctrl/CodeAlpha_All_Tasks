package com.canada.edu.stocktrading.dto;

import lombok.Data;

@Data
public class WsSelectedDto {
    String userId;
    Integer symbolId;
}
