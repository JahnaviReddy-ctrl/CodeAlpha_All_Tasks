package com.canada.edu.stocktrading.model;

public enum AuthenticationType {
    DATABASE,
    GOOGLE,
    FACEBOOK
}
