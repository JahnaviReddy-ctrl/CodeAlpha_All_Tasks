# Iris Flower Classification

This project uses the famous Iris dataset to classify flower species based on measurements using machine learning models.

## Files
- `iris.csv`: Dataset containing Iris flower data.
- `classification.py`: Script to run machine learning models and evaluate results.

## Requirements
Install required libraries:
```
pip install pandas scikit-learn
```

## How to Run
```
python classification.py
```

## Output
- Classification reports for both KNN and Logistic Regression
- Accuracy scores and confusion matrices

## Dataset Source
You can download the full dataset from:
https://www.kaggle.com/datasets/saurabh00007/iriscsv
