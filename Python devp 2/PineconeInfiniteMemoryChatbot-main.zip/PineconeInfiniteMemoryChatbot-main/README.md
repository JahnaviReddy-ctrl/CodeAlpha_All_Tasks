# PineconeInfiniteMemoryChatbot
Let's use Pinecone to give a basic chatbot INFINITE MEMORY
