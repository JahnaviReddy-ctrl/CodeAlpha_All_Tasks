#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

// Function to convert grade (letter or numeric) to grade point
float convertGrade(string grade) {
    if (grade == "A" || grade == "a") return 10.0;
    else if (grade == "B" || grade == "b") return 8.0;
    else if (grade == "C" || grade == "c") return 6.0;
    else if (grade == "D" || grade == "d") return 4.0;
    else if (grade == "F" || grade == "f") return 0.0;
    else {
        cout << "Invalid grade entered. Defaulting to 0." << endl;
        return 0.0;
    }
}

int main() {
    int numCourses;
    vector<string> courseNames;
    vector<string> grades;
    vector<int> creditHours;
    vector<float> gradePoints;

    float totalGradePoints = 0;
    int totalCredits = 0;

    cout << "🔢 Enter number of courses: ";
    cin >> numCourses;

    for (int i = 0; i < numCourses; ++i) {
        string courseName, grade;
        int credits;

        cout << "\n📚 Course " << (i + 1) << " Name: ";
        cin.ignore();
        getline(cin, courseName);

        cout << "🎓 Grade (A/B/C/D/F): ";
        cin >> grade;

        cout << "⏱️ Credit Hours: ";
        cin >> credits;

        float gradePoint = convertGrade(grade) * credits;

        courseNames.push_back(courseName);
        grades.push_back(grade);
        creditHours.push_back(credits);
        gradePoints.push_back(gradePoint);

        totalCredits += credits;
        totalGradePoints += gradePoint;
    }

    float GPA = totalGradePoints / totalCredits;

    // Display summary
    cout << "\n\n📊 Semester Summary:\n";
    cout << "------------------------------------------------------\n";
    cout << setw(20) << left << "Course"
         << setw(10) << "Grade"
         << setw(10) << "Credits"
         << setw(15) << "Grade Points" << endl;
    cout << "------------------------------------------------------\n";

    for (int i = 0; i < numCourses; ++i) {
        cout << setw(20) << left << courseNames[i]
             << setw(10) << grades[i]
             << setw(10) << creditHours[i]
             << setw(15) << fixed << setprecision(2) << gradePoints[i] << endl;
    }

    cout << "------------------------------------------------------\n";
    cout << "Total Credits: " << totalCredits << "\n";
    cout << "Total Grade Points: " << totalGradePoints << "\n";
    cout << "📌 Final CGPA: " << fixed << setprecision(2) << GPA << "\n";

    return 0;
}
