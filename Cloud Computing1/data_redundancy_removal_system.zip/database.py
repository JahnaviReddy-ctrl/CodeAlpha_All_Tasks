import sqlite3

def init_db():
    conn = sqlite3.connect("db.sqlite3")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS cloud_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data TEXT UNIQUE
        )
    """)
    conn.commit()
    conn.close()

def insert_data(data):
    conn = sqlite3.connect("db.sqlite3")
    c = conn.cursor()
    try:
        c.execute("INSERT INTO cloud_data (data) VALUES (?)", (data,))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def fetch_all_data():
    conn = sqlite3.connect("db.sqlite3")
    c = conn.cursor()
    c.execute("SELECT data FROM cloud_data")
    rows = c.fetchall()
    conn.close()
    return [row[0] for row in rows]