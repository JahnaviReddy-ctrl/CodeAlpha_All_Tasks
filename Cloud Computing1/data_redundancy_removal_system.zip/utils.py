def is_redundant(new_data, existing_data_list):
    new_data = new_data.strip().lower()
    return new_data in (data.lower() for data in existing_data_list)