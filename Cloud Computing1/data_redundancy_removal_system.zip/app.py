from flask import Flask, render_template, request, jsonify
from database import init_db, insert_data, fetch_all_data
from utils import is_redundant

app = Flask(__name__)
init_db()

@app.route("/", methods=["GET", "POST"])
def home():
    message = ""
    if request.method == "POST":
        user_data = request.form["data"]
        existing = fetch_all_data()
        if is_redundant(user_data, existing):
            message = "❌ Data already exists or is redundant."
        else:
            if insert_data(user_data):
                message = "✅ Data added successfully!"
            else:
                message = "⚠️ Error inserting data."
    return render_template("index.html", message=message)

@app.route("/api/data", methods=["GET"])
def api_data():
    return jsonify(fetch_all_data())

if __name__ == "__main__":
    app.run(debug=True)