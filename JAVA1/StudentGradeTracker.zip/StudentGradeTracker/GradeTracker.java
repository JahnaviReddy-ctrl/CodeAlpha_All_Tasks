import java.util.ArrayList;

public class GradeTracker {
    private ArrayList<Student> students = new ArrayList<>();

    public void addStudent(String name, double grade) {
        students.add(new Student(name, grade));
    }

    public double getAverageGrade() {
        double total = 0;
        for (Student s : students) {
            total += s.getGrade();
        }
        return students.size() > 0 ? total / students.size() : 0;
    }

    public double getHighestGrade() {
        double max = Double.MIN_VALUE;
        for (Student s : students) {
            if (s.getGrade() > max) {
                max = s.getGrade();
            }
        }
        return max;
    }

    public double getLowestGrade() {
        double min = Double.MAX_VALUE;
        for (Student s : students) {
            if (s.getGrade() < min) {
                min = s.getGrade();
            }
        }
        return min;
    }

    public void showReport() {
        System.out.println("\n--- Student Grade Report ---");
        for (Student s : students) {
            System.out.println("Name: " + s.getName() + ", Grade: " + s.getGrade());
        }
        System.out.printf("Average Grade: %.2f%n", getAverageGrade());
        System.out.printf("Highest Grade: %.2f%n", getHighestGrade());
        System.out.printf("Lowest Grade: %.2f%n", getLowestGrade());
    }
}
