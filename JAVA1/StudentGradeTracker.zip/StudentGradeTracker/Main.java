import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GradeTracker tracker = new GradeTracker();

        System.out.println("Welcome to the Student Grade Tracker!");

        while (true) {
            System.out.print("\nEnter student name (or 'done' to finish): ");
            String name = scanner.nextLine();
            if (name.equalsIgnoreCase("done")) break;

            System.out.print("Enter grade for " + name + ": ");
            double grade = scanner.nextDouble();
            scanner.nextLine(); // consume newline

            tracker.addStudent(name, grade);
        }

        tracker.showReport();
        scanner.close();
    }
}
