
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

bool registerUser(const string& username, const string& password) {
    ifstream infile("users.txt");
    string storedUser, storedPass;

    while (infile >> storedUser >> storedPass) {
        if (storedUser == username) {
            cout << "Username already exists!" << endl;
            return false;
        }
    }
    infile.close();

    ofstream outfile("users.txt", ios::app);
    outfile << username << " " << password << endl;
    cout << "User registered successfully!" << endl;
    return true;
}

bool loginUser(const string& username, const string& password) {
    ifstream infile("users.txt");
    string storedUser, storedPass;

    while (infile >> storedUser >> storedPass) {
        if (storedUser == username && storedPass == password) {
            cout << "Login successful!" << endl;
            return true;
        }
    }
    cout << "Invalid credentials!" << endl;
    return false;
}

int main() {
    int choice;
    string username, password;

    cout << "1. Register\n2. Login\nEnter choice: ";
    cin >> choice;

    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    if (choice == 1)
        registerUser(username, password);
    else if (choice == 2)
        loginUser(username, password);
    else
        cout << "Invalid choice!" << endl;

    return 0;
}
