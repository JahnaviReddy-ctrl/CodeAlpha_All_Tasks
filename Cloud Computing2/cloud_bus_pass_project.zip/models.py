import uuid

def calculate_fare(route, pass_type):
    base_fares = {
        'City A to B': 50,
        'City B to C': 70,
        'City A to C': 100
    }
    multiplier = 1 if pass_type == 'Regular' else 1.5
    return int(base_fares.get(route, 60) * multiplier)

def generate_pass_id(name, route, date):
    return str(uuid.uuid4())[:8]