import sqlite3

def init_db():
    conn = sqlite3.connect('db.sqlite3')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS bus_passes (
            id TEXT PRIMARY KEY,
            name TEXT,
            route TEXT,
            date TEXT,
            type TEXT,
            fare INTEGER
        )
    ''')
    conn.commit()
    conn.close()

def insert_pass(pass_id, name, route, date, pass_type, fare):
    conn = sqlite3.connect('db.sqlite3')
    c = conn.cursor()
    c.execute('''
        INSERT OR REPLACE INTO bus_passes (id, name, route, date, type, fare)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (pass_id, name, route, date, pass_type, fare))
    conn.commit()
    conn.close()