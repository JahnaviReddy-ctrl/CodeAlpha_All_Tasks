from flask import Flask, render_template, request, redirect, url_for
from database import init_db, insert_pass
from models import calculate_fare, generate_pass_id

app = Flask(__name__)
init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/book', methods=['POST'])
def book():
    name = request.form['name']
    route = request.form['route']
    date = request.form['date']
    pass_type = request.form['pass_type']
    
    fare = calculate_fare(route, pass_type)
    pass_id = generate_pass_id(name, route, date)

    insert_pass(pass_id, name, route, date, pass_type, fare)

    return render_template('success.html', name=name, pass_id=pass_id, fare=fare)

if __name__ == '__main__':
    app.run(debug=True)