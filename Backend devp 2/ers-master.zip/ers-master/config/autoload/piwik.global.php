<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

# copy this file to piwik.local.php
# uncomment the return
# do additional changes in piwik.local.php


/*return array(
    'orgHeiglPiwik' => array(

        // Always omit a trailing slash!
        'server' => 'prereg.eja.net/analytics',
        'site_id' => 1,
    ), 
);*/
return array();