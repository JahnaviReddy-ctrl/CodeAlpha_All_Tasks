<?php

/*return array(
    'ERS\SEPA' => array(
        'iban'      => 'NL84 INGB 0007 8721 92',
        'bic'       => 'INGBNL2A',
        'owner'     => 'STICHTING EUROPEAN JUGGLING ASSOCIATION',
        'bank'      => 'ING BANK N.V.',
        'country'   => 'Netherlands',
    )
);*/
return array();