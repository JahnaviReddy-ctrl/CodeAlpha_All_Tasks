<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

# copy this file to ipayment.local.php
# uncomment the return
# do additional changes in ipayment.local.php

/*return array(
    'ERS\iPayment' => array(
        'trxuser_id'    => '99999',
        'trx_currency'  => 'EUR',
        'trxpassword'   => '0',
        'sec_key'       => '1234567890',
        'action'        => 'https://ipayment.de/merchant/%account_id%/processor/2.0/',
    )
);*/
return array();