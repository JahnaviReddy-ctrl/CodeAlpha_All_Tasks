<?php   

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace OnsiteReg\Form;

use Zend\Form\Form;


class ConfirmItems extends Form
{
    public function __construct()
    {
        parent::__construct('ConfirmItems');
        $this->setAttribute('method', 'post');
        
        $this->add(array(
            'name' => 'id',
            'attributes' => array(
                'type'  => 'hidden',
            ),
        ));
       
        $this->add(array( 
            'name' => 'csrf', 
            'type' => 'Zend\Form\Element\Csrf',
            'options' => array(
                // Increase timeout to 30 minutes.
                'csrf_options' => array('timeout' => 1800),
            ),
        ));
        
        $this->add(array(
            'name' => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => 'Confirm',
                'class' => 'btn btn-lg btn-success confirm-items-button',
            ),
        ));
    }
}