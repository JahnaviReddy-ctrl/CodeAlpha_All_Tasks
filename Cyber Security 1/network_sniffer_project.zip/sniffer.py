from scapy.all import sniff, IP, TCP, UDP, Raw

def process_packet(packet):
    print("="*60)
    if IP in packet:
        ip_layer = packet[IP]
        print(f"[+] Source IP: {ip_layer.src}")
        print(f"[+] Destination IP: {ip_layer.dst}")
        print(f"[+] Protocol: {ip_layer.proto}")

        if TCP in packet:
            print("[+] TCP Packet")
            print(f"    Src Port: {packet[TCP].sport} -> Dst Port: {packet[TCP].dport}")
        elif UDP in packet:
            print("[+] UDP Packet")
            print(f"    Src Port: {packet[UDP].sport} -> Dst Port: {packet[UDP].dport}")
        
        if Raw in packet:
            print("[+] Payload:")
            try:
                print(packet[Raw].load.decode(errors='ignore'))
            except:
                print("    [Binary Data]")

def start_sniffer(interface="eth0"):
    print(f"[*] Starting packet capture on interface: {interface}")
    sniff(iface=interface, prn=process_packet, store=False)

if __name__ == "__main__":
    from scapy.all import get_if_list
    print("Available interfaces:", get_if_list())
    interface = input("Enter network interface (e.g., eth0, wlan0): ")
    start_sniffer(interface)