const { expect } = require("chai");

describe("SimpleStorage Contract", function () {
  let SimpleStorage;
  let storage;
  let owner;

  beforeEach(async function () {
    SimpleStorage = await ethers.getContractFactory("SimpleStorage");
    [owner] = await ethers.getSigners();
    storage = await SimpleStorage.deploy();
    await storage.deployed();
  });

  it("Should start with value 0", async function () {
    const val = await storage.value();
    expect(val).to.equal(0);
  });

  it("Should increment value by 1", async function () {
    await storage.increment();
    const val = await storage.value();
    expect(val).to.equal(1);
  });

  it("Should decrement value by 1", async function () {
    await storage.decrement();
    const val = await storage.value();
    expect(val).to.equal(-1);
  });

  it("Should increment then decrement and return to 0", async function () {
    await storage.increment();
    await storage.decrement();
    const val = await storage.getValue();
    expect(val).to.equal(0);
  });
});
