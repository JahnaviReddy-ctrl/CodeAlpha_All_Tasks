import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv('books.csv')

# Clean data: Remove currency symbol and convert to float
df['Price'] = df['Price'].str.replace('£', '').astype(float)

# Set style
sns.set(style="whitegrid")

# Histogram
plt.figure(figsize=(10, 5))
sns.histplot(df['Price'], bins=10, kde=True, color='skyblue')
plt.title('Distribution of Book Prices')
plt.xlabel('Price (£)')
plt.ylabel('Number of Books')
plt.savefig('histogram.png')
plt.show()

# Boxplot
plt.figure(figsize=(8, 4))
sns.boxplot(x=df['Price'], color='lightcoral')
plt.title('Boxplot of Book Prices')
plt.xlabel('Price (£)')
plt.savefig('boxplot.png')
plt.show()
