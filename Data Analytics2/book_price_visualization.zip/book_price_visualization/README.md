# Book Price Visualization

This project visualizes book prices using Python libraries: Matplotlib and Seaborn.

## Files
- `books.csv`: Sample book data with prices.
- `visualization.py`: Python script to generate histogram and boxplot.
- `histogram.png`: Distribution of book prices.
- `boxplot.png`: Price spread using boxplot.

## How to Run
1. Install dependencies:
   ```
   pip install pandas matplotlib seaborn
   ```

2. Run the script:
   ```
   python visualization.py
   ```

3. Output images (`histogram.png` and `boxplot.png`) will be generated.

## Insights
This project helps in understanding price distribution and detecting any price outliers.
