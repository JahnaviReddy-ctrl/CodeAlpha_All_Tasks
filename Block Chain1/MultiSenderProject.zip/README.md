# MultiSender Smart Contract

## 💡 Description
A Solidity smart contract to send equal ETH amounts to multiple addresses in a single transaction.

## ⚙️ How It Works
- Deploy the contract using Remix or Hardhat.
- Call `multiSend()` with:
  - A list of recipient addresses.
  - Total ETH amount (will be split equally).

## 🧪 Example
Sending 3 ETH to 3 addresses:

```
multiSend(["0xAbc...", "0xDef...", "0xGhi..."])
Value: 3 ETH
```

Each address receives 1 ETH.

## 🧰 Technologies
- Solidity (0.8.19)
- Hardhat (for local testing/deployment)
- Remix IDE (for easy testing)
