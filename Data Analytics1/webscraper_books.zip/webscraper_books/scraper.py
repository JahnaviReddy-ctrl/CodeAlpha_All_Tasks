import requests
from bs4 import BeautifulSoup
import pandas as pd

# Step 1: Send GET request
url = 'https://books.toscrape.com/catalogue/page-1.html'
response = requests.get(url)

# Step 2: Parse HTML
soup = BeautifulSoup(response.content, 'html.parser')

# Step 3: Extract data
books = soup.find_all('article', class_='product_pod')
book_list = []

for book in books:
    title = book.h3.a['title']
    price = book.find('p', class_='price_color').text
    book_list.append({'Title': title, 'Price': price})

# Step 4: Save to CSV
df = pd.DataFrame(book_list)
df.to_csv('books.csv', index=False)

print("Scraped and saved successfully!")
