# Book Web Scraper

This project scrapes book titles and prices from [Books to Scrape](https://books.toscrape.com), 
a practice website for web scraping.

## Files
- `scraper.py`: Python script to scrape data using BeautifulSoup.
- `books.csv`: Output file (generated after running the script).

## How to Run
1. Install dependencies:
   ```
   pip install requests beautifulsoup4 pandas
   ```

2. Run the script:
   ```
   python scraper.py
   ```

3. The scraped data will be saved in `books.csv`.

Happy scraping!
