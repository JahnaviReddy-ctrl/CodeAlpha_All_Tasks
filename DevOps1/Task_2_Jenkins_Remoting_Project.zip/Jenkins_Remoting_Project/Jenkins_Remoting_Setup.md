# Jenkins Remoting Project

## 1. Setup Jenkins Controller
- Install Jenkins
- Start service
- Access via browser `http://localhost:8080`

## 2. Setup Jenkins Agent
- Create directory and install Java
- Copy `agent.jar` and start agent with JNLP

## 3. Connect Agent
- Use secret key and JNLP URL from Jenkins node config

## 4. Run Remote Job
- Create job in Jenkins
- Assign it to run on agent using label
